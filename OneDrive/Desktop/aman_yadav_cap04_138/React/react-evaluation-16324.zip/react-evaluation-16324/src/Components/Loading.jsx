const Loading = () => {
  return <div data-testid="loading">Loading...</div>;
};

export default Loading;
